# Hackspark Clone

A clone-style template inspired by hackspark.in.

## Usage
Open `index.html` in a browser.

## Structure
- index.html
- css/style.css
- js/main.js
- assets/images/

Replace placeholder images in `assets/images/` and `assets/logo.png`.
