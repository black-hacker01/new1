// main.js — interactivity for Hackspark clone
const themeBtn = document.getElementById('themeBtn');
function setTheme(t){ document.body.setAttribute('data-theme', t); localStorage.setItem('hs_theme', t);} 
if(themeBtn){ themeBtn.addEventListener('click', ()=>{ const cur=document.body.getAttribute('data-theme')==='light'?'dark':'light'; setTheme(cur); }); }
const saved=localStorage.getItem('hs_theme'); if(saved) setTheme(saved);
const projectGrid=document.getElementById('projectGrid');
if(projectGrid){[{title:'IoT Dashboard',desc:'Realtime sensors & visualizer',img:'assets/images/p1.jpg'},
{title:'Autonomous Robot',desc:'Pathfinding demo',img:'assets/images/p2.jpg'},
{title:'Tooling Library',desc:'Open-source builder tools',img:'assets/images/p3.jpg'}].forEach(p=>{
  const el=document.createElement('div');el.className='project';
  el.innerHTML=`<img src="${p.img}" alt="${p.title}"/><div class="meta"><h4>${p.title}</h4><p>${p.desc}</p></div>`;
  projectGrid.appendChild(el);
});}
const contactForm=document.getElementById('contactForm');
if(contactForm){contactForm.addEventListener('submit',async e=>{e.preventDefault();alert('Message sent (stub). Replace with backend call.');contactForm.reset();});}
